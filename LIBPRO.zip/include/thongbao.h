#ifndef THONGBAO
#define THONGBAO

#include <thuvien_chuan.h>
bool Xemthongbao(Nguoidung & Ngdung_dangnhap);
#endif