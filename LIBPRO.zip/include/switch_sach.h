#ifndef SWITCHSACH
#define SWITCHSACH
#include <thuvien_chuan.h>
void Switch_timkiem(Nguoidung &Ngdung_dangnhap,std::vector<std::string>SachGiaoTrinh,sach & Giaotrinh);
void switchinsach(Nguoidung &Ngdung_dangnhap,std::vector<std::string>SachGiaoTrinh,sach & Giaotrinh);
#endif