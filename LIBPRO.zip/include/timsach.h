#ifndef	TIMSACH
#define TIMSACH
#include <thuvien_chuan.h>
bool timsach_theoten(Nguoidung & Ngdung_dangnhap, std::vector<std::string>SachGiaoTrinh, sach & Giaotrinh);
bool timsach_theloai(Nguoidung &Ngdung_dangnhap, std::vector<std::string>SachGiaoTrinh, sach &Giaotrinh);
#endif