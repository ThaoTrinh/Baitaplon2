#ifndef DOIMATKHAU
#define DOIMATKHAU

#include <thuvien_chuan.h>
bool Doimatkhau(std::vector<Nguoidung>& Dangnhap, Nguoidung & Ngdung_dangnhap);
#endif 