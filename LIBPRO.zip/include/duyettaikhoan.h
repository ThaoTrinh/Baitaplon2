#ifndef DUYETTAIKHOAN
#define DUYETTAIKHOAN

#include <thuvien_chuan.h>

bool duyettaikhoan();
bool xoachucnang(int maso);
bool xoadangnhap(int maso);
bool xoathongtin(int maso);
bool xoaduyet(int maso);
bool xoaten(int maso);
#endif#pragma once
