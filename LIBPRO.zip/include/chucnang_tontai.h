#ifndef  CHUCNANGTONTAI
#define CHUCNANGTONTAI

#include <thuvien_chuan.h>
bool chucnang_tontai(Nguoidung& Ngdung_dangnhap, int chon);

#endif