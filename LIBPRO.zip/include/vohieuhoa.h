#ifndef	VOHIEUHOA
#define VOHIEUHOA

#include <thuvien_chuan.h>

bool vohieuhoa(Nguoidung & Ngdung_dangnhap);
bool kichhoat(Nguoidung &Ngdung_dangnhap);
bool davohieuhoa(Nguoidung &Ngdung_dangnhap);
#endif