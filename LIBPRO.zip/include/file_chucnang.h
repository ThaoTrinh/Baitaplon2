#ifndef FILECHUCNANG
#define FILECHUCNANG

#include <thuvien_chuan.h>

bool file_themchucnang();
bool file_huychucnang();
bool capnhat_themchucnang(Nguoidung& Ngdung_dangnhap, int chon);
bool capnhat_huychucnang(Nguoidung& Ngdung_dangnhap, int chon);
#endif