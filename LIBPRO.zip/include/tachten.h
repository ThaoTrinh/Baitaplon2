//#ifndef TACHTEN
//#define TACHTEN
//#include <thuvien_chuan.h>
//
//#endif