#ifndef QUENMATKHAU
#define QUENMATKHAU

#include <thuvien_chuan.h>
bool quenmatkhau();
bool resetmatkhau();
#endif