#ifndef INSACH
#define INSACH

#include <thuvien_chuan.h>
bool infilevanhoc();
bool infileKHTN();
void InDanhSach_Sach_TacGia(std::string str, int bien);
bool infilegiaotrinh(Nguoidung &Ngdung_dangnhap,std::vector<std::string>SachGiaoTrinh,sach & Giaotrinh);

#endif