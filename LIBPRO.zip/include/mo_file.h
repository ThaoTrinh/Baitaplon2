//#ifndef MOFILE
//#define MOFILE
//#include <thuvien_chuan.h>
//
//bool file_trong();
//#endif