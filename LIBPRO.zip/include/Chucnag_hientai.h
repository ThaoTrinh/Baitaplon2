#ifndef CHUCNANGHIENTAI
#define CHUCNANGHIENTAI

#include <thuvien_chuan.h>
void Xuatchucnang(std::vector<Nguoidung>& Dangnhap, Nguoidung& Ngdung_dangnhap);

#endif