#ifndef DANGNHAP
#define DANGNHAP

#include <thuvien_chuan.h>
#include <Docdulieu.h>

bool Log_in(std::vector<Nguoidung>&,Nguoidung &Ngdung_dangnhap);
void Dangnhapvao(std::vector<Nguoidung>& Dangnhap, Nguoidung& Ngdung_dangnhap);

#endif