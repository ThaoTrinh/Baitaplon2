#ifndef Doc_FileSach
#define Doc_FileSach
#include "thuvien_chuan.h"

bool Doc_file_SachGiaoTrinh();
bool Doc_file_SachVanHoc();
bool Doc_file_SachKHTN();

#endif // !Doc_FileSach

#pragma once
