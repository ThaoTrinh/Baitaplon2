#ifndef CHUCNANG
#define CHUCNANG
#include <thuvien_chuan.h>

bool Themchucnang(std::vector<Nguoidung>& Dangnhap,Nguoidung & Ngdung_dangnhap);
bool Huychucnang(std::vector<Nguoidung>& Dangnhap,Nguoidung & Ngdung_dangnhap);
#endif