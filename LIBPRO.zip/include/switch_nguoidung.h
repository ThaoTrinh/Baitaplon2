#ifndef SWITCHNGUOIDUNG
#define SWITCHNGUOIDUNG
#include <thuvien_chuan.h>

void Switch_docgia(std::vector<thongtin_nguoidung>& Dangki_taikhoan,std::vector<Nguoidung>& Dangnhap,Nguoidung & Ngdung_dangnhap,std::vector<std::string>SachGiaoTrinh,sach & Giaotrinh);
void Switch_thuthu(std::vector<thongtin_nguoidung>& Dangki_taikhoan,std::vector<Nguoidung>& Dangnhap,Nguoidung & Ngdung_dangnhap);
void Switch_quanli(std::vector<thongtin_nguoidung>& Dangki_taikhoan,std::vector<Nguoidung>& Dangnhap,Nguoidung & Ngdung_dangnhap);

#endif