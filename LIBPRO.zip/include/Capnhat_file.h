#ifndef CAPNHATFILE
#define CAPNHATFILE

#include <thuvien_chuan.h>

bool capnhat_doimatkhau(std::vector<Nguoidung>& Dangnhap, Nguoidung & Ngdung_dangnhap);
bool capnhat_dangnhap(std::vector<Nguoidung>& Dangnhap, Nguoidung& Ngdung_dangnhap);
bool trong_chucnang();
bool trongchucnang();
bool trongvao_chucnang();
//bool chucnang_trong();
#endif