#ifndef DuyetTraSach
#define DuyetTraSach

#include <thuvien_chuan.h>
void phat(int id, std::string tensach);
void so_sach(std::string tensach, int soluong);
void duyet_tra_sach();

#endif