#ifndef TUYCHONSACH
#define TUYCHONSACH

#include <thuvien_chuan.h>

int tuychoninsach();
int timkiem();

#endif