#ifndef THONGTINCANHAN
#define THONGTINCANHAN

#include <thuvien_chuan.h>
bool Thongtin_canhan(int&);
bool laythongtin(int maso);
#endif