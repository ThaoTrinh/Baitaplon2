#ifndef MuonSach
#define MuonSach

#include <thuvien_chuan.h>
#include <switch_nguoidung.h>
void Muonsach();
void DuyetYeuCauMuonSach();
void HienThiDanhSachCacLoaiSach();
bool VietPhieuMuonSach();

#endif // !MuonSach

#pragma once
