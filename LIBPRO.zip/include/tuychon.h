#ifndef TUYCHON
#define TUYCHON
#include <thuvien_chuan.h>

int Tuychon(std::vector<Nguoidung>& Dangnhap,Nguoidung & Ngdung_dangnhap);
int Tuychon_docgia(std::vector<Nguoidung>& Dangnhap,Nguoidung & Ngdung_dangnhap);
int Tuychon_thuthu(std::vector<Nguoidung>& Dangnhap,Nguoidung & Ngdung_dangnhap);
int Tuychon_Quanli(std::vector<Nguoidung>& Dangnhap,Nguoidung & Ngdung_dangnhap);
int Tuychon_chucnang(std::vector<Nguoidung>& Dangnhap,Nguoidung & Ngdung_dangnhap);

#endif