#ifndef SWITCH
#define SWITCH
#include <thuvien_chuan.h>

int Caidat();
void Caidat_switch(std::vector<Nguoidung>& Dangnhap, Nguoidung & Ngdung_dangnhap);
void Switch_Chucnang(std::vector<thongtin_nguoidung>& Dangki_taikhoan,std::vector<Nguoidung>& Dangnhap,Nguoidung &Ngdung_dangnhap,std::vector<std::string>SachGiaoTrinh,sach &Giaotrinh);

#endif