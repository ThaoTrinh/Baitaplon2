#ifndef DuyetMuonSach
#define DuyetMuonSach

#include <thuvien_chuan.h>

NguoiMuon Xu_li_dong(std::string line, NguoiMuon& NGUOI_MUON);
void sua_so_luong_sach(NguoiMuon NGUOI_MUON);
void duyet_muon_sach();

#endif