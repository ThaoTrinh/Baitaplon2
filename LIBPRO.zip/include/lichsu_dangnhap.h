#ifndef LICHSUDANGNHAP
#define LICHSUDANGNHAP
#include <thuvien_chuan.h>

bool dangnhap_lichsu(Nguoidung & Ngdung_dangnhap);
#endif