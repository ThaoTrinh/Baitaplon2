#ifndef  traSach
#define traSach

#include <thuvien_chuan.h>
void Tra_Sach(Nguoidung &Ngdung_dangnhap);
#endif // ! traSach

#pragma once
