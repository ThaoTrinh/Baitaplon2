#ifndef NHAPPHIEU
#define NHAPPHIEU

#include <thuvien_chuan.h>
void Nhapphieumuonsach(Nguoidung& Ngdung_dangnhap,std::vector<std::string>SachGiaoTrinh,sach & Giaotrinh);
void ThoiGianMuon(int& date, int& month, int& year);

#endif