#ifndef BIETHIEU
#define BIETHIEU
#include <thuvien_chuan.h>
bool biethieu(int bien1);
#endif